NULL GENESIS / CUDA canonical collection. Native artwork is exactly 30 x 30 ASCII cells.
DNA marked AES-256-GCM remains encrypted. The owner key is excluded.
Browser generation uses WebGPU or a CPU worker. Original artwork was rendered using NVIDIA CUDA.
Download all seven parts for the complete 3333 editions. Animation exports are available from Animation Studio.
